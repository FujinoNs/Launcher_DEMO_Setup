-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.14-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.1.0.6116
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for kc_launcher
CREATE DATABASE IF NOT EXISTS `kc_launcher` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;
USE `kc_launcher`;

-- Dumping structure for table kc_launcher.kc_anti_cheat
CREATE TABLE IF NOT EXISTS `kc_anti_cheat` (
  `cheat_name` varchar(1000) COLLATE utf8mb4_bin DEFAULT NULL,
  `label_cheat_name` varchar(1000) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- Dumping data for table kc_launcher.kc_anti_cheat: ~3 rows (approximately)
/*!40000 ALTER TABLE `kc_anti_cheat` DISABLE KEYS */;
REPLACE INTO `kc_anti_cheat` (`cheat_name`, `label_cheat_name`) VALUES
	('cheatengine-x86_64', 'Cheat Engine'),
	('ProcessHacker', 'ProcessHacker'),
	('GH Injector', 'GH Injector');
/*!40000 ALTER TABLE `kc_anti_cheat` ENABLE KEYS */;

-- Dumping structure for table kc_launcher.kc_update
CREATE TABLE IF NOT EXISTS `kc_update` (
  `version` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `url_download` varchar(1000) COLLATE utf8mb4_bin DEFAULT NULL,
  `description` varchar(5000) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- Dumping data for table kc_launcher.kc_update: ~1 rows (approximately)
/*!40000 ALTER TABLE `kc_update` DISABLE KEYS */;
REPLACE INTO `kc_update` (`version`, `url_download`, `description`) VALUES
	('7.1', 'https://github.com/FujinoNs/Launcher_DEMO_Setup', '1.เพิ่มระบบ Anti-Cheat (ขึ้นอยู่ที่adminจะให้กันโปรแกรมอะไรบ้าง)\r\n2.เพิ่มโหมดการเชื่อมต่อและ API ให้รองรับ Join (cfx.re/join/abc123) และ Http (http://localhost:30120/)\r\n3.เพิ่มระบบ Report ผ่าน Discord\r\n4.เพิ่มระบบ DiscordRPC \r\n5.เพิ่มระบบการเก็บ Logging\r\n6.เพิ่มระบบลบแคช FiveM');
/*!40000 ALTER TABLE `kc_update` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
